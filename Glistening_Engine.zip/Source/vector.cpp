
#include "vector.h"

//default constructor
CVector::CVector()
{
    x = 0.0f; y = 0.0f; z = 0.0f;
}

//initializer constructor
CVector::CVector(float X, float Y, float Z)
{
    x = X; y = Y; z = Z;
}

//CVector negation
CVector CVector::operator -()
{
	*this *= -1.0f;
	return *this;
}

//CVector addition
CVector CVector::operator +(CVector Addend)
{
    return CVector(x + Addend.x, y + Addend.y, z + Addend.z);
}

//CVector subtraction
CVector CVector::operator -(CVector Minuend)
{
    return CVector(x - Minuend.x, y - Minuend.y, z - Minuend.z);
}

//Scalar division
CVector CVector::operator /(float Scalar)
{
    return CVector(x / Scalar, y / Scalar, z / Scalar);
}

//Scalar multiplication
CVector CVector::operator *(float Scalar)
{
    return CVector(x * Scalar, y * Scalar, z * Scalar);
}

//CVector increment
CVector CVector::operator +=(CVector Addend)
{
    x += Addend.x;
    y += Addend.y;
    z += Addend.z;

    return *this;
}

//CVector decrement
CVector CVector::operator -=(CVector Minuend)
{
    x -= Minuend.x;
    y -= Minuend.y;
    z -= Minuend.z;

    return *this;
}

//Scalar divide
CVector CVector::operator /=(float Scalar)
{
    if(Scalar != 0.0f)
	{
		x /= Scalar;
		y /= Scalar;
		z /= Scalar;
	}

    return *this;
}

//Scalar multiply
CVector CVector::operator *=(float Scalar)
{
    x *= Scalar;
    y *= Scalar;
    z *= Scalar;

    return *this;
}

//get CVector length
float CVector::operator !()
{
    return sqrt(x*x + y*y + z*z);
}

float CVector::length()
{
	return !(*this);
}

//set CVector length
CVector CVector::norm()
{
	return *this /= !(*this);
}

//return dot product of *this and Param
float CVector::dot(CVector Param)
{
    return (x * Param.x + y * Param.y + z * Param.z);
}

//cross product operator
CVector CVector::cross(CVector Param)
{
    return CVector(y * Param.z - z * Param.y,
                   z * Param.x - x * Param.z,
                   x * Param.y - y * Param.x);
}

void CVector::Output()
{
	glVertex3fv(&x);
}

