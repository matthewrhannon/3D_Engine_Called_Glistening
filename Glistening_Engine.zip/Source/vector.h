//I got this from ominous project. caffenine engine
//I will make my own when i get a chance...

#ifndef _VECTOR_
#define _VECTOR_

#include "cafmath.h"
#include "Constants.h"
#include "Defaults.h"

class CVector
{
    public:
        float x;    //coordinates, basically an ordered ternary
        float y;
        float z;

        CVector();
        CVector(float, float, float);

        //CVector negation
		CVector CVector::operator -();

		//CVector addition
        CVector operator +(CVector Addend);
        //CVector subtraction
        CVector operator -(CVector Minuend);  
        //Scalar division
        CVector operator /(float Scalar);
        //Scalar multiplication
        CVector operator *(float Scalar);

        //CVector increment
        CVector operator +=(CVector Addend);
        //CVector decrement
        CVector operator -=(CVector Minuend);
        //Scalar divide
        CVector operator /=(float Scalar);
        //Scalar multiply
        CVector operator *=(float Scalar);

        //get CVector length
        float operator !();
		float length();
        //CVector normalize
        CVector norm();
        //return dot product of *this and Param
        float dot(CVector Param);
        //return cross-product of *this and Param
        CVector cross(CVector Param);

		void Output();  // sends the vector as a vertex to OpenGL
};

#endif