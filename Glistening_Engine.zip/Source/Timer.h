//Febuary ??, 2002
//By Matt H.

#ifndef _TIMER_
#define _TIMER_

#include "Defaults.h"

class CTimer
{
	public:
		static CTimer *Get()
		{
			if(!Instance)
				Instance = new CTimer;
			return Instance;
		};
		
		void UpdateTimer();
		float ReturnFps();
		float GetRunningTime();
		float GetTimePassed(float StartTime);
		float GetTimeBasedTime();

	protected:
		CTimer()
		{
			QueryPerformanceCounter(&StartTick);
			QueryPerformanceFrequency(&Frequency);
		}
		~CTimer()
		{
			if(Instance)
				delete Instance;
			Instance = 0;
		}
		
	private:
		static CTimer *Instance;
		float FramesPerSecond;
		LARGE_INTEGER StartTick;
		LARGE_INTEGER Frequency;
		LARGE_INTEGER StartFrameTick;
		LARGE_INTEGER EndFrameTick;








};










#endif