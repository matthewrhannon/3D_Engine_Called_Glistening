//Febuary 14, 2002
//By Matt H.

#ifndef _PLAYER_
#define _PLAYER_

#include "Constants.h"
#include "Defaults.h"
#include "Camera.h"
#include "Log.h"
#include "Text.h"
#include "Texture.h"
#include "Timer.h"
#include "Game.h"
#include "Object.h"

extern float Speed;
extern float PLAYER_FORWARD;
extern float PLAYER_SIDEWAYS;
extern float PLAYER_BACKWARDS;

class CPlayer : public CObject
{
	public:
		static CPlayer *Get()
		{
			if(!Instance)
				Instance = new CPlayer;
			return Instance;
		}

		CPlayer()
		{
			Speed = 4.5;
			PLAYER_FORWARD = Speed;
			PLAYER_SIDEWAYS = Speed;
			PLAYER_BACKWARDS = Speed;

			Height = 3.5;
			UnderWater = false;
			Jumping = false;
			HitPoints = 100;
		}

		CPlayer(CVector Position1, int HitPoints1)
		{
			Speed = 2.5;
			PLAYER_FORWARD = Speed;
			PLAYER_SIDEWAYS = Speed;
			PLAYER_BACKWARDS = Speed;

			
			Height = 3.5;
			UnderWater = false;
			Jumping = false;
			HitPoints = HitPoints1;
			Position = Position1;
		}
		
	public:
		void MoveForward(float Speed);
		void MoveSideWays(float Speed);
		void MoveBackWards(float Speed);
		void RotateView(float Pitch, float Yaw);
		void UpdateCamera();

		void Shoot();
		void Jump();
		void ApplyGravity(float TimeBased);
		
		void SetPlayerSpeed(float Speed);
		void SetPosition(CVector Position);
		void SetHitpoints(int HitPoints);

	protected:
		virtual void OnDraw();
		virtual void OnAnimate(float TimeBased);
		~CPlayer()
		{
			if(Instance)
				delete Instance;
			Instance = 0;
		}

	private:
		static CPlayer *Instance;
		int HitPoints;

		float Height;
		bool UnderWater;
		bool Jumping;

};






#endif