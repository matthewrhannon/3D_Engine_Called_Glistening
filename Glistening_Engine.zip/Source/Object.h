//Febuary 14, 2002
//By Matt H.

#ifndef _OBJECT_
#define _OBJECT_

//Fixed problem. Declaring abovw ith #ifdef not #ifndef very mean errror. now i think about it not really.
//Just reason through it and it is very easy...
//I think the problem is i am not declaring an instance of this classs. very strange........  

#include "Constants.h"
#include "Defaults.h"
#include "vector.h"

class CObject
{	
	public:
		CObject()
		{
			Position = CVector(0.0f, 0.0f, 0.0f);
			Rotation = CVector(0.0f, 0.0f, 0.0f);
			Velocity = CVector(0.0f, 0.0f, 0.0f);
			Acceloration = CVector(0.0f, 0.0f, 0.0f);

			Size = 2.0f;
		}

		float GetSize();
		void SetSize(float Size1);		
		
		void SetAcceloration(CVector Acceloration1);
		void SetLocation(CVector Position1);
		void SetVelocity(CVector Velocity1);
	
		CVector GetVelocity();
		CVector GetLocation();
		CVector GetAcceloration();
		
	public:
		virtual void OnDraw();
		virtual void OnAnimate(float TimeBased);
		virtual void OnAI();
		virtual void OnCollision(CObject *Object);

	public:
		void Draw();
		void Animate(float TimeBased);
		void AI();
		void Collision(CObject *Object);
	
	public:
		CVector Position;
		CVector Rotation;
		CVector Velocity;
		CVector Acceloration;
		float Size;

};



#endif