//Febuary 2, 2002
//By Matt H.

#include "Engine.h"


CEngine *CEngine::Instance = 0;


CEngine::CEngine(WINDOW *WindowInfo)
{
	CWindows98::Get()->DisplayWindow(WindowInfo->Title, WindowInfo->Width, WindowInfo->Height, WindowInfo->Bpp, WindowInfo->AskFullScreen);
	//Windows98::Get()->DisplayWindow(WindowInfo);
}