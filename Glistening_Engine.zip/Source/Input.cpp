//Febuary ??, 2002
//By Matt H.

#include "Input.h"

CInput *CInput::Instance = 0;

bool CInput::IsKeyDown(int Key)
{
	return (GetAsyncKeyState(Key) & 0x8000 ? true : false);
}

void CInput::GetMouseMovement(int &x, int &y)
{
	static bool First = true;
	if(First)
	{
		RECT Window;
		GetWindowRect(CWindows98::Get()->GetHWND(), &Window);
		CenterPoint.x = Window.right/2;
		CenterPoint.y = Window.bottom/2;
	}
	
	GetCursorPos(&Point);

	x = CenterPoint.x - Point.x;
	y = CenterPoint.y - Point.y;

	SetCursorPos(CenterPoint.x, CenterPoint.y);
}


float CInput::ReturnMouseSense()
{
	return MouseSensitivity;
}

void CInput::SetMouseSense(float MouseSense)
{
	MouseSensitivity = MouseSense;
}