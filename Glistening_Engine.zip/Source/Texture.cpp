//Febuary 6, 2002
//By Matt H.

#include "Texture.h"


AUX_RGBImageRec *CTexture::LoadBitmap(char *FilePath)				
{
	if (!FilePath)									
		return NULL;								

	File = fopen(FilePath,"r");						

	if (File)										
	{
		fclose(File);									
		return auxDIBImageLoad(FilePath);			
	}

	return NULL;									
}

void CTexture::LoadTexture(char *FilePath)
{
	memset(TextureImage,0,sizeof(void *)*1);          

	if (TextureImage[0] = LoadBitmap(FilePath))
	{
		glGenTextures(1, &Id);				
		glBindTexture(GL_TEXTURE_2D, Id);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, 3, TextureImage[0]->sizeX, TextureImage[0]->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, TextureImage[0]->data);
	}
	else
		CLog::Get()->WriteLog("Error loading file", 2);

	if (TextureImage[0])								
	{
		if (TextureImage[0]->data)							
		{
			free(TextureImage[0]->data);				
		}

		free(TextureImage[0]);							
	}

}



void CTexture::UseTexture()
{
	glBindTexture(GL_TEXTURE_2D, Id);
}

CTexture::~CTexture()
{
	if(Id)
		glDeleteTextures(1, &Id);
}
