//Febuary 9, 2002
//By Matt H.

#ifndef _CAMERA_
#define _CAMERA_

#include "vector.h"
#include "Constants.h"
#include "Defaults.h"
#include "Input.h"
#include "Timer.h"

class CCamera
{
	public:
		static CCamera *Get()
		{	
			if(!Instance)
				Instance = new CCamera;
			return Instance;
		};
		
		void Update();
		void Initalize(float Speed1, CVector Position1, float Yaw1, float Pitch1);
		void GetPostion(CVector &Position1);
		void GetAngles(float &Yaw1, float &Pitch1);
		void GetSpeed(float &Speed1);
		void SetPosition(CVector Position1);
		void SetAngles(float Yaw1, float Pitch1);
		void SetSpeed(float Speed1);
	protected:
		CCamera();
		//~CCamera();
	private:
		static CCamera *Instance;
		CVector Position;
		POINT Pos;
		float Yaw, Pitch;
		float Speed;
};

#endif	

/*

Update camera


	glRotatef(camera.anglePitch, 1.0f, 0.0f, 0.0f);
	glRotatef(camera.angleYaw, 0.0f, 1.0f, 0.0f);
	glTranslatef(-camera.position.x, -camera.position.y, -camera.position.z);
	*/

/*

Camera Position: (0.0 0.875 0.0)
Camera Orientation: 0.0 0.0
*/