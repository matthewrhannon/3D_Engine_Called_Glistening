//Febuary 14, 2002
//By Matt H.

#include "Player.h"

CPlayer *CPlayer::Instance = 0;

float Speed;
float PLAYER_FORWARD;
float PLAYER_SIDEWAYS;
float PLAYER_BACKWARDS;

void CPlayer::MoveForward(float Speed)
{
	if(!Jumping)
	{
		Velocity.x += Speed*cos(Rotation.y*DEGTORAD);
		Velocity.z += Speed*sin(Rotation.y*DEGTORAD);
	}
}

void CPlayer::MoveSideWays(float Speed)
{
	if(!Jumping)
	{
		Velocity.x += Speed*cos((Rotation.y+90.0f)*DEGTORAD);
		Velocity.z += Speed*sin((Rotation.y+90.0f)*DEGTORAD);
	}
}

void CPlayer::MoveBackWards(float Speed)
{
	Speed = -Speed;
	if(!Jumping)
	{
		Velocity.x += Speed*cos(Rotation.y*DEGTORAD);
		Velocity.z += Speed*sin(Rotation.y*DEGTORAD);
	}
}


void CPlayer::RotateView(float Yaw, float Pitch)
{
	Rotation.x -= Pitch;
	if(Rotation.x > 90.0f)
		Rotation.x = 90.0f;
	if(Rotation.x < -90.0f)
		Rotation.x = -90.0f;
    Rotation.y -= Yaw;
	if(Rotation.y > 180.0f)
		Rotation.y = -180.0f;
	if(Rotation.y < -180.0f)
		Rotation.y = 180.0f;
}

void CPlayer::ApplyGravity(float TimeBased)
{




}

void CPlayer::Jump()
{




}

void CPlayer::Shoot()
{






}

void CPlayer::SetPosition(CVector Position)
{






}

void CPlayer::SetHitpoints(int HitPoints)
{




}

void CPlayer::SetPlayerSpeed(float Speed)
{





}

void CPlayer::UpdateCamera()
{
	CCamera::Get()->SetPosition(Position);
	CCamera::Get()->SetAngles(Rotation.x, Rotation.y);
	CCamera::Get()->Update();
}

void CPlayer::OnDraw()
{






}

void CPlayer::OnAnimate(float TimeBased)
{
	Position.y = 1.5;

	Position += Velocity*TimeBased;
}