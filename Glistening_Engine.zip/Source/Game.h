//Feburary 2, 2002
//Matt H.

#ifndef _GAME_
#define _GAME_

#include "Defaults.h"
#include "Constants.h"
#include "Engine.h"
#include "Windows98.h"
#include "Texture.h"
#include "Camera.h"
#include "Log.h"
#include "Input.h"
#include "Timer.h"
#include "Object.h"
#include "Player.h"
#include "Sky.h"
#include "Text.h"

extern WINDOW WindowInfo;

class CGame
{
	public:
		static CGame *Get()
		{
			if(!Instance)
				Instance = new CGame;
			return Instance;
		};

		void InitalizeGL();
		void Running();
		bool RunSystem();
		void CheckKeys();
	protected:
        CGame()
		{
			Done = false;
		}
		~CGame()
        {
            if(Instance)
                delete Instance;
            Instance = 0;
        };

	private:
		static CGame *Instance;
		
		CFont *FontText;

		WINDOW WindowInfo;
	
		bool Done;


};










#endif