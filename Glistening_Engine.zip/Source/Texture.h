//Febuary 6, 2002
//By Matt H.


#ifndef _TEXTURE_
#define _TEXTURE_

#include "Constants.h"
#include "Defaults.h"
#include "Log.h"

class CTexture
{
	public:
		void LoadTexture(char *FilePath);
		void UseTexture();	
		AUX_RGBImageRec *LoadBitmap(char *FilePath);
		~CTexture();

	private:
		unsigned int Id;
		AUX_RGBImageRec *TextureImage[1];
		FILE *File;	

};


#endif