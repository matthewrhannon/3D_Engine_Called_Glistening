//Febuary 6, 2002
//By Matt H.

#ifndef _FONT_
#define _FONT_

#include "Constants.h"
#include "Defaults.h"
#include "Windows98.h"

class CFont
{
	public:	
		CFont(char *FontName, int Height);
		~CFont();
		
		void BuildFont(char *FontName, int Height);
		void KillFont();
		void Print(int x, int y, char *String);
		void PrintEx(int x, int y, char *String, ...);
		void SetColor(float Red1, float Green1, float Blue1, float Alpha1);

	private:
		unsigned int base;
		float Red, Green, Blue, Alpha;
};


#endif