//Febuary 17, 2002
//By Matt H.

#ifndef _SKY_
#define _SKY_

#include "Defaults.h"
#include "Constants.h"
#include "Texture.h"
#include "Log.h"

class CSky
{
	public:
		static CSky *Get()
		{
			if(!Instance)
				Instance = new CSky;
			return Instance;
		}
		void SetSkyDir(char *Directory1);
		void SetSkyInfo(float Length1, float Width1, float Height1);
		//void SetSkyInfo(int X1, int Y1, int Length1, int Width1, int Height1);
		void UpdateSky();

	protected:
		~CSky()
		{
			if(Instance)
				delete Instance;
			Instance = 0;
		}

	private:
		static CSky *Instance;
		float Length, Width, Height;
		//int X, Y;
		char *Directory;
		char Path[40];
		CTexture Top, Bottom, Right, Left, Front, Back;
};



#endif