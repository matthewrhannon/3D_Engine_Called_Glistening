//Febuary 2, 2002
//By Matt H.


#include "Windows98.h"


CWindows98 *CWindows98::Instance = 0;


LONG CALLBACK WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	switch(Msg)
	{
		case WM_INITDIALOG:

		break;

		case WM_SIZE:
			CWindows98::Get()->SizeWindow(LOWORD(lParam), HIWORD(lParam));
		break;

		case WM_DESTROY:
		case WM_CLOSE:
			return 0;
		break;
	}
	return DefWindowProc(hWnd, Msg, wParam, lParam);
}

void CWindows98::DisplayWindow(char *Title1, int Width1, int Height1, int Bpp1, bool AskFullScreen1)
{
	//Store some varibles
	Title = Title1;
	Width = Width1;
	Height = Height1;
	Bpp = Bpp1;
	AskFullScreen = AskFullScreen1;
	

	//Much cleaner and more effective NOTE doesnt work.. doesnt pass chars right. something on my side
	//Dont have time to figure out
	//WindowData = WindowInfo;

	if(AskFullScreen)
		if(MessageBox(NULL, "Would you like FullScreen?", "Question..", MB_YESNO) == IDYES)
			FullScreen = true;
		else
			FullScreen = false;

	if(!AskFullScreen)
		FullScreen = true;

	hInstance = GetModuleHandle(NULL);

	memset(&WindowClass, 0, sizeof(WNDCLASSEX));

	WindowClass.cbSize = sizeof(WNDCLASSEX);
	WindowClass.style = CS_OWNDC | CS_HREDRAW | CS_VREDRAW;
	WindowClass.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
	WindowClass.lpfnWndProc = WndProc;
	WindowClass.hIcon = NULL;;
	WindowClass.hCursor = LoadCursor(0, IDC_ARROW);
	WindowClass.hInstance = hInstance;
	WindowClass.lpszClassName = WINDOWCLASS;
	
	
	if(!RegisterClassEx(&WindowClass))
		return;

	ChangeDisplaySettings(NULL,0);

	if(FullScreen)											
	{
		memset(&dmScreenSettings, 0, sizeof(dmScreenSettings));	
		dmScreenSettings.dmSize = sizeof(dmScreenSettings);	
		dmScreenSettings.dmPelsWidth = Width;			
		dmScreenSettings.dmPelsHeight = Height;			
		dmScreenSettings.dmBitsPerPel = Bpp;			
		dmScreenSettings.dmFields = DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!= DISP_CHANGE_SUCCESSFUL)
		{
			MsgBox("Changing the display settings failed.");
			FullScreen = false;
		}
	}

	if (FullScreen)										
	{
		ExStyle = WS_EX_APPWINDOW;								
		Style = WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN;	
		ShowCursor(false);								
	}
	else
	{
		ExStyle = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE; 
		Style = WS_POPUP | WS_VISIBLE;
	}

	if (!(hWnd=CreateWindowEx(ExStyle, WINDOWCLASS, Title, Style, 0, 0, Width, Height, NULL, NULL, hInstance, NULL)))				
	{
		KillWindow();		
		MsgBox("Cant create the window..");
		return;	
	}

	static PIXELFORMATDESCRIPTOR pfd =			
	{
		sizeof(PIXELFORMATDESCRIPTOR),			
		1,									
		PFD_DRAW_TO_WINDOW |				
		PFD_SUPPORT_OPENGL |				
		PFD_DOUBLEBUFFER,							
		PFD_TYPE_RGBA,							
		Bpp,									
		0, 0, 0, 0, 0, 0,						
		0,										
		0,										
		0,										
		0, 0, 0, 0,								
		16,										
		0,									
		0,										
		PFD_MAIN_PLANE,							
		0,											
		0, 0, 0										
	};
	
	if (!(hDC = GetDC(hWnd)))							
	{
		KillWindow();							
		MsgBox("Having problems obtaining a DC");
		return;							
	}

	if (!(PixelFormat = ChoosePixelFormat(hDC,&pfd)))
	{
		KillWindow();							
		MsgBox("Having trouble creating the PixelFormat");
		return;						
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))	
	{
		KillWindow();							
		MsgBox("Having trouble setting up the PixelFormat");
		return;							
	}

	if (!(hRC = wglCreateContext(hDC)))		
	{
		KillWindow();							
		MsgBox("Having trouble creating the wgl handle");
		return;							
	}

	if(!wglMakeCurrent(hDC,hRC))				
	{
		KillWindow();					
		MsgBox("Having trouble setting the wgl handle");
		return;						
	}

	ShowWindow(hWnd, SW_SHOW);						
	SetForegroundWindow(hWnd);						
	SetFocus(hWnd);								
	SizeWindow(Width, Height);				

	return;
}


void CWindows98::KillWindow()						
{
	if(hRC)										
	{
		wglMakeCurrent(NULL,NULL);		
		wglDeleteContext(hRC);				
		hRC = NULL;									
	}

	ReleaseDC(hWnd,hDC);	
	hDC = NULL;									
	DestroyWindow(hWnd);		
	
	hWnd=NULL;									
	
	if (FullScreen)									
	{
		ChangeDisplaySettings(NULL,0);				
		ShowCursor(true);						
	}
}

void CWindows98::SizeWindow(int Width1, int Height1)
{
	if(Height1 == 0)
		Height1 = 1;

	glViewport(0, 0, Width1, Height1);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	
	gluPerspective(60.0f, (double)Width1/(double)Height1, 0.1f, 10000.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	Width = Width1;
	Height = Height1;

	return;
}

bool CWindows98::Process(bool Done)
{
	
	while(PeekMessage(&Msg, 0, 0, 0, PM_NOREMOVE))
	{
		if(GetMessage(&Msg, 0, 0, 0))
		{
			TranslateMessage(&Msg);
			DispatchMessage(&Msg);
		}
	}
	if(Done)
	{
		KillWindow();
		return false;
	}
		

	return true;
}

HDC CWindows98::GetHDC()
{
	return hDC;
}

HWND CWindows98::GetHWND()
{
	return hWnd;
}

/*
bool CWindows98::IsSession()
{
	return SessionOver;
}
*/

void CWindows98::GetWindowInformation(WINDOW *WindowInfo)
{
	WindowInfo->Height = Height;
	WindowInfo->Width = Width;
	WindowInfo->Bpp = Bpp;
	WindowInfo->AskFullScreen = AskFullScreen;
	strcpy(WindowInfo->Title, Title);
}