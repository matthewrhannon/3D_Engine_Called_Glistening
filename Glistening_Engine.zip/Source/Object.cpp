//Febuary 14, 2002
//By Matt H.

#include "Object.h"

void CObject::OnAnimate(float TimeBased)
{



}

void CObject::Animate(float TimeBased)
{
	OnAnimate(TimeBased);
}

void CObject::OnDraw()
{



}

void CObject::Draw()
{	
	glPushMatrix();
		OnDraw();   
	glPopMatrix();
}

void CObject::OnAI()
{



}

void CObject::AI()
{
	OnAI();
}

void CObject::OnCollision(CObject *Object)
{



}

void CObject::Collision(CObject *Object)
{
	OnCollision(Object);
}

float CObject::GetSize()
{
	return Size;
}

void CObject::SetSize(float Size1)
{
	Size = Size1;

}

CVector CObject::GetLocation()
{
	return Position;
}

void CObject::SetLocation(CVector Position1)
{
	Position = Position1;
}

void CObject::SetAcceloration(CVector Acceloration1)
{
	Acceloration = Acceloration1;
}

CVector CObject::GetAcceloration()
{
	return Acceloration;
}

void CObject::SetVelocity(CVector Velocity1)
{
	Velocity = Velocity1;
}

CVector CObject::GetVelocity()
{
	return Velocity;
}

