#ifndef _WINDOWS98_
#define _WINDOWS98_

#include "Constants.h"
#include "Defaults.h"
#include "Game.h"
#include "Engine.h"
#include "Input.h"

class CWindows98
{
	public:	
		static CWindows98 *Get()
		{
			if(!Instance)
				Instance = new CWindows98;
			return Instance;
		};

		void DisplayWindow(char *Title, int Width, int Height, int Bpp, bool AskFullScreen1);
		void GetWindowInformation(WINDOW *WindowInfo);
		void KillWindow();
		void SizeWindow(int Width, int Height);
		bool Process(bool Done);
		HDC GetHDC();
		HWND GetHWND();
		//bool IsSession();
		//LONG CALLBACK WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);

	protected:
		CWindows98()
		{
			SessionOver = true;
		}
		~CWindows98()
		{
			if(Instance)
				delete Instance;
			Instance = 0;
		}
	private:
		static CWindows98 *Instance;
		
		char *Title;
		int Width, Height, Bpp;
		int PixelFormat;
		bool AskFullScreen;
		bool FullScreen;
		bool SessionOver;
		WNDCLASSEX WindowClass;
		DEVMODE dmScreenSettings;
		HINSTANCE hInstance;
		HDC hDC;
		HGLRC hRC;
		DWORD ExStyle;			
		DWORD Style;	
		HWND hWnd;
		MSG Msg;
	
		//Much more effective and clean   NOTE doesnt work. check .cpp for details
		//WINDOW *WindowData;

};


#endif