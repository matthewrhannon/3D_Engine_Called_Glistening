//Feburary ??, 2002
//By Matt H.

#include "Timer.h"

CTimer *CTimer::Instance = 0;

void CTimer::UpdateTimer()
{
	FramesPerSecond = float(Frequency.QuadPart / double(EndFrameTick.QuadPart - StartFrameTick.QuadPart));
	
	StartFrameTick = EndFrameTick;

	QueryPerformanceCounter(&EndFrameTick);
}

float CTimer::ReturnFps()
{
	return FramesPerSecond;
}

float CTimer::GetTimePassed(float StartTime)
{
	return float(GetRunningTime() - StartTime);
}

float CTimer::GetRunningTime()
{
	return (StartFrameTick.QuadPart - StartTick.QuadPart)/(float)Frequency.QuadPart;
}

float CTimer::GetTimeBasedTime()
{
	return 1/FramesPerSecond;
}