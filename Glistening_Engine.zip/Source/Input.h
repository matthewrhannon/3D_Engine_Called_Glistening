//Febuary ??, 2002
//By Matt H.

#ifndef _INPUT_
#define _INPUT_

#include "Defaults.h"
#include "Windows98.h"

class CInput
{
	public:
		static CInput *Get()
		{
			if(!Instance)
				Instance = new CInput;
			return Instance;
		};

		bool IsKeyDown(int Key);
		void GetMouseMovement(int &x, int &y);
		float ReturnMouseSense();
		void SetMouseSense(float MouseSense);

	protected:
		CInput()
		{
			MouseSensitivity = .3f;
		}

		~CInput()
		{
			if(Instance)
				delete Instance;
			Instance = 0;
		}
	
	private:
		static CInput *Instance;
		POINT Point;
		POINT CenterPoint;
		float MouseSensitivity;



};










#endif