//Borrowed from Ominous
//Caffenine engine
//I didnt make :-)

#ifndef CAFFEINE_CAFMATH
#define CAFFEINE_CAFMATH

#include "Defaults.h"
#include "Constants.h"

const float PI = 3.141592653589793f;
const float PIOVER180 = PI/180.0f;

const float DEGTORAD = PIOVER180;
const float RADTODEG = 1/PIOVER180;

const float GRAVITY = -32.174f;

#endif