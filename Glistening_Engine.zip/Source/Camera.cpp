//Febuary 9, 2002
//By Matt H.

#include "Camera.h"

CCamera *CCamera::Instance = 0;

CCamera::CCamera()
{
	Position = CVector(0.0f, 1.5f, 0.0f);
	Speed = 1.0f;
	Yaw = 0.0f;
	Pitch = 0.0f;
}

void CCamera::Initalize(float Speed1, CVector Position1, float Yaw1, float Pitch1)
{
	Speed = Speed1;
	Position = Position1;
	Yaw = Yaw1;
	Pitch = Pitch1;
	SetCursorPos(320, 240);
}

void CCamera::Update()
{
	glRotatef(Yaw, 1, 0, 0);
	glRotatef(90.0f + Pitch, 0, 1, 0);
	glTranslatef(-Position.x, -Position.y, -Position.z);
}

void CCamera::GetPostion(CVector &Position1)
{
	Position1 = Position;
}

void CCamera::GetAngles(float &Yaw1, float &Pitch1)
{
	Yaw1 = Yaw;
	Pitch1 = Pitch;
}

void CCamera::GetSpeed(float &Speed1)
{
	Speed1 = Speed;
}

void CCamera::SetPosition(CVector Position1)
{
	Position = Position1;
}

void CCamera::SetAngles(float Yaw1, float Pitch1)
{
	Yaw = Yaw1;
	Pitch = Pitch1;
}

void CCamera::SetSpeed(float Speed1)
{
	Speed = Speed1;
}