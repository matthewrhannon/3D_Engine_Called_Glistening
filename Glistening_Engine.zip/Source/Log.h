//Febuary 6, 2002
//By Matt H.
//Just got book, probley stop working on this for awhile (Programming Gems)

#ifndef _LOG_
#define _LOG_

#include "Constants.h"
#include "Defaults.h"

#define	FILE_HEADER 100
#define	FILE_SUBHEADER 200
#define	FILE_ENDER  300

class CLog
{
	public:
		static CLog *Get()
		{
			if(!Instance)
				Instance = new CLog;
			return Instance;
		};
		
		void LoadLog();
		void WriteLog(char *Text, int Type);
		void WriteLogEx(int Type, char *Text, ...);
		void CloseLog();

	protected:
		CLog()
		{
			LoadLog();
		}
		~CLog()
		{
			CloseLog();
			if(Instance)
				delete Instance;
			Instance = 0;

		}

	private:
		static CLog *Instance;
		FILE *File;
};






#endif
