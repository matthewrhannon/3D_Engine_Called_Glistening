//Febuary 4, 2002
//By Matt H.

#ifndef _CONSTANTS_
#define _CONSTANTS_

#define WINDOWCLASS "TheGlistening"

struct WINDOW
{
	char Title[20];
	int Width;
	int Height;
	int Bpp;
	bool AskFullScreen;
};


typedef enum GAME_STATES
{
	GAME_INITALIZE = 100,
	
	GAME_MENU_INIT = 200,
	GAME_MENU_RUN = 210,
	GAME_MENU_SHUTDOWN = 220,
	GAME_RUNNING = 110,

	GAME_SHUTDOWN = 120,
};

/*
typedef enum FILE_TYPES
{
	FILE_HEADER = 100,
	FILE_SUBHEADER = 110,
	FILE_ENDER = 120,
};
*/

#endif