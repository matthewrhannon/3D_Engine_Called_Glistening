//Feburary 2, 2002
//Matt H.


#ifndef _DEFAULTS_
#define _DEFAULTS_

#include <windows.h>
#include <WinBase.h>
#include <Winnt.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <fstream.h>
#include <math.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glaux.h>

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#pragma comment(lib, "glaux.lib")
//#pragma comment(lib, "bass.lib")

//This if for the input. Sometimes theseee arent defined so here they are
#ifndef VK_1     
	#define VK_1 48
	#define VK_2 49
	#define VK_3 50
	#define VK_4 51
	#define VK_5 52
	#define VK_6 53
	#define VK_7 54
	#define VK_8 55
	#define VK_9 56
	#define VK_0 57
#endif

#ifndef VK_A
	#define VK_A 65
	#define VK_B 66
	#define VK_C 67
	#define VK_D 68
	#define VK_E 69
	#define VK_F 70
	#define VK_G 71
	#define VK_H 72
	#define VK_I 73
	#define VK_J 74
	#define VK_K 75
	#define VK_L 76
	#define VK_M 77
	#define VK_N 78
	#define VK_O 79
	#define VK_P 80
	#define VK_Q 81
	#define VK_R 82
	#define VK_S 83
	#define VK_T 84
	#define VK_U 85
	#define VK_V 86
	#define VK_W 87
	#define VK_X 88
	#define VK_Y 89
	#define VK_Z 90
#endif

//Handy MessageBox thingy. Good and fast for debugging
inline void MsgBox(char *String, ...)
{
	char String1[256];
	va_list List;
	va_start(List, String);
	vsprintf(String1, String, List);
	va_end(List);

	MessageBox(NULL, String1, "Information", MB_OK);
}

#endif