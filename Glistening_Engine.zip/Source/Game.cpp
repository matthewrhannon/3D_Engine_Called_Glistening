//Febuary 2, 2002
//By Matt H.

#include "Game.h"

CGame *CGame::Instance = 0;

void CGame::Running()
{
	//Could possibly do dialog box here and
	//have the user select stuff like resolutions and bpp's.
	//Back to the program...

	WindowInfo.Height = 480;
	WindowInfo.Width = 640;
	WindowInfo.Bpp = 16;
	WindowInfo.AskFullScreen = true;
	strcpy(WindowInfo.Title, "The Glistening");

	CEngine::Get(&WindowInfo);

	InitalizeGL();

	for(;;)
	{
		if(CWindows98::Get()->Process(Done) && !Done)
		{
			if(!RunSystem())
				Done = true;

			//Sleep(1);
		}
		else
		{
			break;
		}
	}
	//Do shutdowns and clean up heres
	CLog::Get()->CloseLog();
	ShowCursor(true);

}

void CGame::InitalizeGL()
{
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_DEPTH_TEST);
	glShadeModel(GL_SMOOTH);

	FontText = new CFont("Times New Roman", 12);

	CTimer::Get()->UpdateTimer();
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);	
		
	CSky::Get()->SetSkyDir("Data/Sky/");
	CSky::Get()->SetSkyInfo(52, 52, 20);
}

void CGame::CheckKeys()
{
	static int X, Y;
	static float MouseSense;

	MouseSense = CInput::Get()->ReturnMouseSense();

	CInput::Get()->GetMouseMovement(X, Y);

	CPlayer::Get()->RotateView(X*MouseSense, Y*MouseSense);
	
	if(CInput::Get()->IsKeyDown(VK_W))
		CPlayer::Get()->MoveForward(PLAYER_FORWARD);

	if(CInput::Get()->IsKeyDown(VK_A))
		CPlayer::Get()->MoveSideWays(-PLAYER_SIDEWAYS);

	if(CInput::Get()->IsKeyDown(VK_D))
		CPlayer::Get()->MoveSideWays(PLAYER_SIDEWAYS);

	if(CInput::Get()->IsKeyDown(VK_S))
		CPlayer::Get()->MoveBackWards(PLAYER_BACKWARDS);

	if(CInput::Get()->IsKeyDown(VK_LBUTTON))
		CPlayer::Get()->Shoot();

	if(CInput::Get()->IsKeyDown(VK_RBUTTON))
		CPlayer::Get()->Jump();

	if(CInput::Get()->IsKeyDown(VK_ADD))
	{
		MouseSense += 0.1f;
		if(MouseSense > 1.0f)
			MouseSense = 1.0f;
		CInput::Get()->SetMouseSense(MouseSense);
	}
	
	if(CInput::Get()->IsKeyDown(VK_SUBTRACT))
	{
		MouseSense -= 0.1f;
		if(MouseSense < 0.1f)
			MouseSense = 0.1f;
		CInput::Get()->SetMouseSense(MouseSense);
	}	
	
	if(CInput::Get()->IsKeyDown(VK_ESCAPE))
		Done = true;
}



void Draw3DSGrid()
{
	// Turn the lines GREEN
	glColor3ub(0, 255, 0);

	// Draw a 1x1 grid along the X and Z axis'
	for(float i = -50; i <= 50; i += 1)
	{
		// Start drawing some lines
		glBegin(GL_LINES);

			// Do the horizontal lines (along the X)
			glVertex3f(-50, 0, i);
			glVertex3f(50, 0, i);

			// Do the vertical lines (along the Z)
			glVertex3f(i, 0, -50);
			glVertex3f(i, 0, 50);

		// Stop drawing lines
		glEnd();
	}

// Turn the lines GREEN
	glColor3ub(0, 255, 0);

	// Draw a 1x1 grid along the X and Z axis'
	for(i = -50; i <= 50; i += 1)
	{
		// Start drawing some lines
		glBegin(GL_LINES);

			// Do the horizontal lines (along the X)
			glVertex3f(-50, 10, i);
			glVertex3f(50, 10, i);

			// Do the vertical lines (along the Z)
			glVertex3f(i, 10, -50);
			glVertex3f(i, 10, 50);

		// Stop drawing lines
		glEnd();
	}

// Turn the lines GREEN
	glColor3ub(0, 255, 0);

	// Draw a 1x1 grid along the X and Z axis'
	for(i = -50; i <= 50; i += 1)
	{
		// Start drawing some lines
		glBegin(GL_LINES);

			// Do the horizontal lines (along the X)
			glVertex3f(-50, 0, i);
			glVertex3f(-50, 10, i);
		// Stop drawing lines
		glEnd();
	}

// Turn the lines GREEN
	glColor3ub(0, 255, 0);

	// Draw a 1x1 grid along the X and Z axis'
	for(i = -50; i <= 50; i += 1)
	{
		// Start drawing some lines
		glBegin(GL_LINES);

			// Do the horizontal lines (along the X)
			glVertex3f(50, 0, i);
			glVertex3f(50, 10, i);
		// Stop drawing lines
		glEnd();
	}

// Turn the lines GREEN
	glColor3ub(0, 255, 0);

	// Draw a 1x1 grid along the X and Z axis'
	for(i = -50; i <= 50; i += 1)
	{
		// Start drawing some lines
		glBegin(GL_LINES);

			// Do the horizontal lines (along the X)
			glVertex3f(i, 0, -50);
			glVertex3f(i, 10, -50);
		// Stop drawing lines
		glEnd();
	}


// Turn the lines GREEN
	glColor3ub(0, 255, 0);

	// Draw a 1x1 grid along the X and Z axis'
	for(i = -50; i <= 50; i += 1)
	{
		// Start drawing some lines
		glBegin(GL_LINES);
		
			// Do the horizontal lines (along the X)
			glVertex3f(i, 0, 50);
			glVertex3f(i, 10, 50);
		// Stop drawing lines
		glEnd();
	}
}






bool CGame::RunSystem()
{
	CTimer::Get()->UpdateTimer();

	static GAME_STATES Game_State = GAME_INITALIZE;
	switch(Game_State)
	{
		case GAME_INITALIZE:
			Game_State = GAME_MENU_INIT;
		break;

		case GAME_MENU_INIT:
			Game_State = GAME_MENU_RUN;
		break;
		
		case GAME_MENU_RUN:
			Game_State = GAME_MENU_SHUTDOWN;
		break;


		case GAME_MENU_SHUTDOWN:
			Game_State = GAME_RUNNING;
		break;
		
		case GAME_RUNNING:
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glLoadIdentity();
		
			CheckKeys();
			
			CPlayer::Get()->Animate(CTimer::Get()->GetTimeBasedTime());
			CPlayer::Get()->UpdateCamera();
			
			CSky::Get()->UpdateSky();
			Draw3DSGrid();


			CPlayer::Get()->SetVelocity(CVector(0.0f, 0.0f, 0.0f));

			FontText->Print(0, 0, "Please Work");
			/*
			
			glEnable(GL_TEXTURE_2D);
				static CTexture TFont;
				TFont.LoadTexture("Data/Font/Font.bmp");
				TFont.UseTexture();
				glBegin(GL_QUADS);
					glTexCoord2f(0.0f, 0.0f); glVertex3f(-2.0f, -2.0f, -5.0f);
					glTexCoord2f(1.0f, 0.0f); glVertex3f(2.0f, -2.0f, -5.0f);
					glTexCoord2f(1.0f, 1.0f); glVertex3f(2.0f, 2.0f, -5.0f);
					glTexCoord2f(0.0f, 1.0f); glVertex3f(-2.0f, 2.0f, -5.0f);
				glEnd();
			glDisable(GL_TEXTURE_2D);
			*/

			glFlush();
			
			SwapBuffers(CWindows98::Get()->GetHDC());

			if(Done)
				Game_State = GAME_SHUTDOWN;
		break;

		case GAME_SHUTDOWN:
			//Game_State = NULL;
			return false;
		break;
	}
	return true;
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, char *Params, int Show)
{
	CGame::Get()->Running();
	return 0;
}