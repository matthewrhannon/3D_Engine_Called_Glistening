//Febuary 7, 2002
//By Matt H.
//Game Programming Gems, probley quit working on this

/**************************/
//			TO DO
//Start to load all data from files, like paths to log file
//and paths to evrything. have one file. and load it in at run time into defines
//************************/


#include "Log.h"

CLog *CLog::Instance = 0;

void CLog::LoadLog()
{
	//Destroy the contents of the file
	File = fopen("Data/Log.Txt", "w");

	File = fopen("Data/Log.txt", "a+");
	if(!File)
		return;
	fputs("***File Created***", File);
}

void CLog::WriteLog(char *Text, int Type)
{
	if(!strlen(Text))
		return;

	if(Type == FILE_HEADER)
	{
		fprintf(File, "\n%s", Text);
	} 

	if(Type == FILE_ENDER)
	{
		fprintf(File, "\n%s", Text);
	}

	if(Type == FILE_SUBHEADER)
	{
		fprintf(File, "\n	%s", Text);
	}

}

void CLog::WriteLogEx(int Type, char *Text, ...)
{
	if(!strlen(Text)) 
		return;

	va_list List;	
	va_start(List, Text);

	if(Type == FILE_HEADER)
	{
		fprintf(File, "\n");
		vfprintf(File, Text, List);
	}

	if(Type == FILE_ENDER)
	{
		fprintf(File, "\n");
		vfprintf(File, Text, List);
	}

	if(Type == FILE_SUBHEADER)
	{
		fprintf(File, "\n	");
		vfprintf(File, Text, List);
	}

	va_end(List);
}

void CLog::CloseLog()
{
	fputs("\n***File Ending***", File);
	fclose(File);
}
