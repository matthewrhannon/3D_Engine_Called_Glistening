//Febuary 3, 2002
//By Matt H.

#ifndef _ENGINE_
#define _ENGINE_

#include "Defaults.h"
#include "Constants.h"
#include "Game.h"
#include "Windows98.h"
#include "Text.h"
#include "Texture.h"
#include "Camera.h"
#include "Log.h"
#include "Sky.h"

class CEngine
{
	public:
		static CEngine *Get(WINDOW *WindowInfo = 0)
		{
			if(!Instance)
				Instance = new CEngine(WindowInfo);
			return Instance;
		};


	protected:
		CEngine(WINDOW *WindowInfo);
		~CEngine()
        {
            if(Instance)
                delete Instance;
            Instance = 0;
        };
	private:
		static CEngine *Instance;

};







#endif